// Export pages
export '/bienvenida/bienvenida_widget.dart' show BienvenidaWidget;
export '/login/login_widget.dart' show LoginWidget;
export '/contra/contra_widget.dart' show ContraWidget;
export '/cursos/cursos_widget.dart' show CursosWidget;
export '/calendario/calendario_widget.dart' show CalendarioWidget;
export '/perfil/perfil_widget.dart' show PerfilWidget;
export '/menuu/menuu_widget.dart' show MenuuWidget;
export '/cursoss/cursoss_widget.dart' show CursossWidget;
export '/clases/clases_widget.dart' show ClasesWidget;
export '/billetera/billetera_widget.dart' show BilleteraWidget;
export '/clase1/clase1_widget.dart' show Clase1Widget;
export '/clase2/clase2_widget.dart' show Clase2Widget;
export '/clase3/clase3_widget.dart' show Clase3Widget;
export '/contacto/contacto_widget.dart' show ContactoWidget;
export '/miperfil/miperfil_widget.dart' show MiperfilWidget;
