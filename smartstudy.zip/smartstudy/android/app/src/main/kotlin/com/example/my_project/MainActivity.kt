package com.mycompany.smartstudy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
